﻿# traficFines

Trabajo Final de Programación Avanzada en Python para analizar multas de tráfico del Ayuntamiento de Madrid.

## Contenido del proyecto

- Paquete Python `traficFines/`.
- Notebook de la etapa 1 en `enunciado/enunciado.ipynb`.
- Notebook de ejemplos y validación en `notebooks/ejemplos.ipynb`.
- Tests automáticos en `tests/`.
- Distribuciones generadas en `dist/`.

## Estructura del paquete

Dentro del paquete `traficFines/` están los módulos principales:

- `cache.py`: clases `Cache`, `CacheURL` y excepción `CacheError`.
- `traficFines.py`: implementación principal de `MadridFines`, `MadridError` y `get_url`.
- `madridFines.py`: alias del módulo anterior para ajustarse al nombre que aparece en el enunciado.

## Requisitos

- Python 3.10 o superior.
- `pip` disponible en el entorno.

## Instalación

La recomendación es instalar directamente el fichero `.whl` generado en `dist/`:

```bash
python -m pip install dist/traficfines-1.0.0-py3-none-any.whl
```

Se instalarán también las dependencias necesarias del proyecto.

Si se quiere trabajar desde el código fuente del repositorio:

```bash
python -m pip install .
```

Si se quiere trabajar en modo desarrollo:

```bash
python -m pip install -e .
```

## Uso básico

```python
from traficFines import MadridFines

mf = MadridFines(app_name="trafic_fines")
mf.add(2024, 12)

print(mf.loaded)
print(mf.fines_calification())
print(mf.total_payment())
```

Tambien puede importarse el módulo de la siguiente forma:

```python
from traficFines.madridFines import MadridFines
```

## Notebooks

- `enunciado/enunciado.ipynb`: desarrollo de la etapa 1 con descarga, limpieza y preprocesamiento.
- `notebooks/ejemplos.ipynb`: ejemplos de uso y validación de las clases y excepciones.

## Tests

Ejecución de los tests:

```bash
python -m unittest discover tests
```

Ejecución y medición de cobertura:

```bash
python -m coverage run --source=traficFines -m unittest discover tests
python -m coverage report -m
```

## Generación del wheel

```bash
python -m pip install build
python -m build
```

Los archivos generados se guardan en `dist/`, incluyendo el fichero `.whl`.